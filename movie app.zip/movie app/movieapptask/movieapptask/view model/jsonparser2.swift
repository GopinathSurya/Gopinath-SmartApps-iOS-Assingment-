//
//  jsonparser2.swift
//  movieapptask
//
//  Created by Vignesh on 02/04/22.
//

import Foundation


//struct Parser {
//    
//    var json : Welcome?
// 
//    let link = "https://api.themoviedb.org/3/movie/now_playing?api_key=a07e22bc18f5cb106bfe4cc1f83ad8ed"
//    
//    func parse (comp : @escaping ([Result]) -> ()) {
//        
//            guard let url = URL (string : link )else {return}
//
//            let task = URLSession.shared.dataTask(with: url) { (data,response,error) in
//
//                guard error == nil else {return}
//
//                guard let data = data else {return}
//
//                do{
//
//                    let content = try JSONDecoder().decode(Welcome.self, from: data)
//                    print(content.results)
//                    comp(content.results)
//
//                }catch{
//                    
//                    print(error)
//                }
//            }
//           task.resume()
//        }
//    }
