//
//  CollectionViewCell.swift
//  movieapptask
//
//  Created by Vignesh on 02/04/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var picture : UIImageView!
    @IBOutlet weak var label : UILabel!
}
