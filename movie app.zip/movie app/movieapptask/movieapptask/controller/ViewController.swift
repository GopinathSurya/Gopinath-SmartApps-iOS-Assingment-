//
//  ViewController.swift
//  movieapptask
//
//  Created by Vignesh on 02/04/22.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return results.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionview.dequeueReusableCell(withReuseIdentifier: "task", for: indexPath) as! CollectionViewCell
    
       let url = URL(string: "https://image.tmdb.org/t/p/original\(results[indexPath.row].backdropPath)")

       let data = try? Data(contentsOf: url!)

       cell.picture.image = UIImage(data: data!)
        
       cell.label.text = results[indexPath.row].title
        return cell
    
    }
    var result = [String]()
    var poster_path = [String]()
    var genreIDS = [[String]]()
    var parser = Parser()
    var results = [Result]()
   
    @IBOutlet weak var collectionview: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let cellSize = CGSize(width:200 , height:400)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = cellSize
        collectionview.setCollectionViewLayout(layout, animated: true)
        collectionview.reloadData()
        
        parser.parse{
            json in
            self.results = json
            DispatchQueue.main.async {
              self.collectionview.reloadData()
         }
      }
   }
}

